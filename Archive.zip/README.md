# Personal Repo for CoLearning TestBed

- [ ] Reorganize Training Loop to Include Parametrization of Everything
    - [ ] Port 2 MultiBench
- [ ] Add more paper implementations
- [ ] Add 0-shot somehow
